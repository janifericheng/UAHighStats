public class UAHighApp {
    public static void main(String[] args) {
        UAHighStats izuku = new UAHighStats
                ("Izuku Midoria", "Deku", (byte)18,
                        "One for All", (int)166,
                        12373, 104.5F, 0.633,
                        true, (Character)'P');
        UAHighStats bakugo = new UAHighStats
                ("Katski Bakugo", "Great Explosion Murder God Dynamite",
                        (byte)17, "Explosion", (int) 172,
                        22876, 99.5F, 0.76,
                        false, (Character) 'F');
        UAHighStats kirishima = new UAHighStats(
                "Eijiro Kirishima", "Red Riot", (byte)8,
                "Hardening", (int) 170, 3374,
                69.0F, 0.68, false, (Character)'P');

        UAHighStats[] uaHighStats = new UAHighStats[3];
        uaHighStats[0] = izuku;
        uaHighStats[1] = bakugo;
        uaHighStats[2] = kirishima;

        for(UAHighStats uaHighStat : uaHighStats) {
            uaHighStat.nomuThreat();
        }
    }
}
