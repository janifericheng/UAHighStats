import java.util.Random;

    public class UAHighStats {

        String name;
        String heroName;
        Byte seat;
        String quirk;
        int height;
        Integer popPoll5;
        Float statRating;
        Double ranking;
        Boolean passedFinal;
        Character provisionalLicense;

        public UAHighStats(String name, String heroName, Byte seat,
                           String quirk, int height, Integer popPoll5,
                           Float statRating, Double ranking, Boolean passedFinal,
                           Character provisionalLicense) {
            this.name = name;
            this.heroName = heroName;
            this.seat = seat;
            this.quirk = quirk;
            this.height = height;
            this.popPoll5 = popPoll5;
            this.statRating = statRating;
            this.ranking = ranking;
            this.passedFinal = passedFinal;
            this.provisionalLicense = provisionalLicense;
        }

        public void nomuThreat(){
            Random randomNumberGenerator = new Random();
            if(randomNumberGenerator.nextFloat() * 100 > statRating) {
                System.out.println(heroName + " couldn't take down a nomu.");
            } else {
                System.out.println(heroName + " took down a nomu!");
            }

        }

    }

